import discord
from discord.ext import commands

from core.Cog import Cog
from utils.theme import (
    THEME_BLUE,
    THEME_NORMAL,
    get_guild_theme,
    set_guild_theme,
    theme_color,
)


class Theme(Cog, name="theme"):
    """Manage the visual theme used in this server."""

    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="theme")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_guild=True)
    async def theme(self, ctx, selected: str | None = None):
        """Set this server's bot theme. Usage: theme <normal|blue>"""
        if selected is None:
            current = await get_guild_theme(ctx.guild.id)
            embed = discord.Embed(
                title="Server theme",
                description=(
                    f"Current theme: **{current.title()}**\n"
                    f"Use `{ctx.prefix}theme normal` or `{ctx.prefix}theme blue`."
                ),
                color=theme_color(current),
            )
            return await ctx.reply(embed=embed, mention_author=False)

        selected = selected.lower().strip()
        if selected not in (THEME_NORMAL, THEME_BLUE):
            embed = discord.Embed(
                title="Unknown theme",
                description=f"Choose `normal` or `blue`.",
                color=theme_color(await get_guild_theme(ctx.guild.id)),
            )
            return await ctx.reply(embed=embed, mention_author=False)

        await set_guild_theme(ctx.guild.id, selected)
        embed = discord.Embed(
            title="Theme updated",
            description=(
                f"This server now uses the **{selected.title()}** theme.\n"
                "Menus, red embed accents, and available custom emojis will use this theme."
            ),
            color=theme_color(selected),
        )
        await ctx.reply(embed=embed, mention_author=False)

    @theme.error
    async def theme_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            await ctx.reply("You need the **Manage Server** permission to change the theme.", mention_author=False)
            return
        if isinstance(error, commands.NoPrivateMessage):
            await ctx.reply("Themes can only be changed inside a server.", mention_author=False)
            return
        raise error