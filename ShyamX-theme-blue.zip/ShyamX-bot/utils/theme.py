"""Per-guild visual themes for ShyamX.

Blue application emojis are prepared by ``utils.sync_emojis`` during startup.
This module only reads that generated mapping; changing a guild theme never
uploads or edits an emoji.
"""

from __future__ import annotations

import json
import os
import re
from typing import Any

import aiosqlite
import discord


THEME_NORMAL = "normal"
THEME_BLUE = "blue"
VALID_THEMES = frozenset((THEME_NORMAL, THEME_BLUE))

NORMAL_ACCENT = 0xFF0000
BLUE_ACCENT = 0x168BFF

_DB_PATH = os.path.join("db", "themes.db")
_EMOJI_MAP_PATH = os.path.join(os.path.dirname(__file__), "blue_emojis.json")
_theme_cache: dict[int, str] = {}
_emoji_map: dict[str, str] = {}
_emoji_map_mtime: float | None = None
_CUSTOM_EMOJI_RE = re.compile(r"<a?:[^:>]+:\d+>")


async def setup_theme_db() -> None:
    os.makedirs(os.path.dirname(_DB_PATH), exist_ok=True)
    async with aiosqlite.connect(_DB_PATH) as db:
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS guild_themes (
                guild_id INTEGER PRIMARY KEY,
                theme TEXT NOT NULL DEFAULT 'normal'
                    CHECK (theme IN ('normal', 'blue'))
            )
            """
        )
        await db.commit()


async def get_guild_theme(guild_id: int | None) -> str:
    if guild_id is None:
        return THEME_NORMAL
    if guild_id in _theme_cache:
        return _theme_cache[guild_id]

    await setup_theme_db()
    async with aiosqlite.connect(_DB_PATH) as db:
        async with db.execute(
            "SELECT theme FROM guild_themes WHERE guild_id = ?", (guild_id,)
        ) as cursor:
            row = await cursor.fetchone()

    theme = row[0] if row and row[0] in VALID_THEMES else THEME_NORMAL
    _theme_cache[guild_id] = theme
    return theme


async def set_guild_theme(guild_id: int, theme: str) -> str:
    normalized = theme.strip().lower()
    if normalized not in VALID_THEMES:
        raise ValueError(f"Unknown theme: {theme}")

    await setup_theme_db()
    async with aiosqlite.connect(_DB_PATH) as db:
        await db.execute(
            """
            INSERT INTO guild_themes (guild_id, theme) VALUES (?, ?)
            ON CONFLICT(guild_id) DO UPDATE SET theme = excluded.theme
            """,
            (guild_id, normalized),
        )
        await db.commit()
    _theme_cache[guild_id] = normalized
    return normalized


def _load_emoji_map() -> dict[str, str]:
    global _emoji_map, _emoji_map_mtime
    try:
        mtime = os.path.getmtime(_EMOJI_MAP_PATH)
        if _emoji_map_mtime == mtime:
            return _emoji_map
        with open(_EMOJI_MAP_PATH, "r", encoding="utf-8") as file:
            data = json.load(file)
        _emoji_map = {
            str(normal): str(blue)
            for normal, blue in data.items()
            if isinstance(normal, str) and isinstance(blue, str)
        }
        _emoji_map_mtime = mtime
    except (OSError, ValueError, TypeError):
        _emoji_map = {}
        _emoji_map_mtime = None
    return _emoji_map


def theme_color(theme: str) -> int:
    return BLUE_ACCENT if theme == THEME_BLUE else NORMAL_ACCENT


def theme_text(value: str | None, theme: str) -> str | None:
    if value is None or theme != THEME_BLUE:
        return value
    emoji_map = _load_emoji_map()
    return _CUSTOM_EMOJI_RE.sub(lambda match: emoji_map.get(match.group(0), match.group(0)), value)


def _is_normal_red(value: Any) -> bool:
    try:
        return int(value) == NORMAL_ACCENT
    except (TypeError, ValueError):
        return False


def theme_embed(embed: discord.Embed, theme: str) -> discord.Embed:
    if theme != THEME_BLUE:
        return embed
    if _is_normal_red(embed.color):
        embed.color = BLUE_ACCENT
    if embed.title:
        embed.title = theme_text(embed.title, theme)
    if embed.description:
        embed.description = theme_text(embed.description, theme)
    for index, field in enumerate(embed.fields):
        embed.set_field_at(
            index,
            name=theme_text(field.name, theme) or field.name,
            value=theme_text(field.value, theme) or field.value,
            inline=field.inline,
        )
    if embed.footer and embed.footer.text:
        embed.set_footer(
            text=theme_text(embed.footer.text, theme),
            icon_url=embed.footer.icon_url,
        )
    if embed.author and embed.author.name:
        embed.set_author(
            name=theme_text(embed.author.name, theme),
            url=embed.author.url,
            icon_url=embed.author.icon_url,
        )
    return embed


def theme_view(view: Any, theme: str) -> Any:
    if view is None or theme != THEME_BLUE:
        return view

    view._active_theme = theme

    # CV2Embed stores its source text separately and can rebuild itself.
    if hasattr(view, "_title"):
        view._title = theme_text(view._title, theme) or ""
    if hasattr(view, "_description"):
        view._description = theme_text(view._description, theme) or ""
    if hasattr(view, "_fields"):
        view._fields = [
            (theme_text(name, theme) or name, theme_text(value, theme) or value)
            for name, value in view._fields
        ]
    if hasattr(view, "_footer"):
        view._footer = theme_text(view._footer, theme)
    if _is_normal_red(getattr(view, "color", None)):
        view.color = BLUE_ACCENT
    rebuild = getattr(view, "_rebuild", None)
    if callable(rebuild):
        rebuild()

    walker = getattr(view, "walk_children", None)
    children = list(walker()) if callable(walker) else list(getattr(view, "children", []))
    for item in children:
        if _is_normal_red(getattr(item, "accent_color", None)):
            item.accent_color = BLUE_ACCENT
        content = getattr(item, "content", None)
        if isinstance(content, str):
            item.content = theme_text(content, theme)
        emoji = getattr(item, "emoji", None)
        if emoji is not None:
            themed = theme_text(str(emoji), theme)
            if themed != str(emoji):
                try:
                    item.emoji = themed
                except (TypeError, ValueError):
                    pass
        options = getattr(item, "options", None)
        if options:
            for option in options:
                if option.emoji is not None:
                    themed = theme_text(str(option.emoji), theme)
                    if themed != str(option.emoji):
                        option.emoji = themed
    return view


async def theme_message_kwargs(guild_id: int | None, kwargs: dict[str, Any]) -> dict[str, Any]:
    theme = await get_guild_theme(guild_id)
    if theme != THEME_BLUE:
        return kwargs

    content = kwargs.get("content")
    if isinstance(content, str):
        kwargs["content"] = theme_text(content, theme)
    embed = kwargs.get("embed")
    if isinstance(embed, discord.Embed):
        kwargs["embed"] = theme_embed(embed, theme)
    embeds = kwargs.get("embeds")
    if isinstance(embeds, list):
        kwargs["embeds"] = [theme_embed(item, theme) for item in embeds]
    if kwargs.get("view") is not None:
        kwargs["view"] = theme_view(kwargs["view"], theme)
    return kwargs